object ScalaExample{  
    def main(args:Array[String]){  
        println "Hello Scala"  
    }  
}  